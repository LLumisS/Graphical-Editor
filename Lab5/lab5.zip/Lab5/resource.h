﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Lab5.rc
//
#define IDC_MY_TOOLBAR                  1
#define ID_TOOL_POINT                   1
#define IDC_MYICON                      2
#define ID_TOOL_LINE                    2
#define ID_TOOL_RECT                    3
#define ID_TOOL_ELLIPSE                 4
#define ID_TOOL_LINEOO                  5
#define ID_TOOL_CUBE                    6
#define ID_TABLE                        7
#define IDD_LAB5_DIALOG                 102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_LAB5                        107
#define IDI_SMALL                       108
#define IDC_LAB5                        109
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     130
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_32774                        32774
#define IDM_POINT                       32775
#define IDM_LINE                        32776
#define IDM_RECT                        32777
#define IDM_ELLIPSE                     32778
#define IDM_LINEOO                      32786
#define IDM_CUBE                        32787
#define IDM_TABLE                       32789
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32790
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
